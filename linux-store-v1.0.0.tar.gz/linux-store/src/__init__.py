"""
Linux Store - متجر لينكس
تطبيق متجر تطبيقات لنظام لينكس
"""

__version__ = "1.0.0"
__author__ = "Linux Store Team"
__license__ = "MIT"
